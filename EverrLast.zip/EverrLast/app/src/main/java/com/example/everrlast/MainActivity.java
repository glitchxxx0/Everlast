package com.example.everrlast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import com.example.everrlast.ui.login.LoginActivity;
import com.lorentzos.flingswipe.SwipeFlingAdapterView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    SwipeFlingAdapterView flingContainer;
    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor, timerEditor;
    private MatchesAdapter adapter;
    private ArrayList<MatchModel> data_list;
    int i = 0;
    int likeCounts = 0;
    int likeThreshold = 5;

    static final long START_TIME_IN_MILLIS = 3600000;
    long mTimeLeftInMillis;
    Boolean isTimerRunning = false;
    CountDownTimer countDownTimer;
    long mEndTime;
    private final String SharedPrefs = "prefs";
    MatchModel item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        data_list = new ArrayList<MatchModel>();
        sharedPreferences = getSharedPreferences(SharedPrefs, MODE_PRIVATE);

        // Mimic of data fetched from database
        String[] img = new String[]{"https://images.pexels.com/photos/6195166/pexels-photo-6195166.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
        "https://i.pinimg.com/564x/78/f2/ba/78f2bade652cc5ac60d7e5536eccbbe7.jpg",
        "https://i.pinimg.com/564x/f3/a0/ee/f3a0ee48ac9fd836052cc60ac68bd82e.jpg",
        "https://i.pinimg.com/564x/93/96/cb/9396cb10607dce7683e6447db3b662c1.jpg",
        "https://i.pinimg.com/564x/6c/e3/18/6ce318632491a135d2347d0bd4db2f95.jpg",
        "https://i.pinimg.com/564x/0e/30/b9/0e30b907b9bafd783e40e941ad0c3dbf.jpg",
        "https://i.pinimg.com/564x/1b/86/31/1b86313b9df84b21ae59de9f2ff47051.jpg"};

        for(String n: img){
             item = new MatchModel("Name",n,"Unique Identifier","24","RGPV");
            data_list.add(item);
        }




        //choose your favorite adapter
        flingContainer = (SwipeFlingAdapterView) findViewById(R.id.frame1);
        adapter = new MatchesAdapter(this, R.layout.item, data_list);
        flingContainer.setAdapter(adapter);


        //set the listener and the adapter
        flingContainer.setFlingListener(new SwipeFlingAdapterView.onFlingListener() {
            @Override
            public void removeFirstObjectInAdapter() {
                // this is the simplest way to delete an object from the Adapter (/AdapterView)
                Log.d("LIST", "removed object!");


                if (likeCounts > likeThreshold) {
                    //Dialog will open here
                    limitLikesDialog likesDialog = new limitLikesDialog();
                    startTimer();
                    likesDialog.show(getSupportFragmentManager(), "nasty dialog");
                    Toast.makeText(MainActivity.this, "you are out of swipes", Toast.LENGTH_SHORT).show();
                    // data_list.remove(0);
                    data_list.add(data_list.get(0));
                } else {
                    data_list.remove(0);
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onLeftCardExit(Object dataObject) {
                //Do something on the left!
                //You also have access to the original object.
                //If you want to use it just cast it (String) dataObject

            }

            @Override
            public void onRightCardExit(Object dataObject) {

                likeCounts++;
            }

            @Override
            public void onAdapterAboutToEmpty(int itemsInAdapter) {
                // Ask for more data here

                adapter.notifyDataSetChanged();
                Log.d("LIST", "notified");
                i++;
            }

            @Override
            public void onScroll(float v) {

            }
        });

        // Optionally add an OnItemClickListener
        flingContainer.setOnItemClickListener(new SwipeFlingAdapterView.OnItemClickListener() {
            @Override
            public void onItemClicked(int itemPosition, Object dataObject) {
                Toast.makeText(MainActivity.this, "Clicked", Toast.LENGTH_SHORT).show();

            }
        });




    }
    private void startTimer() {
        mEndTime = System.currentTimeMillis() + mTimeLeftInMillis;
        countDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
            }

            @Override
            public void onFinish() {
                isTimerRunning = false;
                timerEditor = sharedPreferences.edit();
                timerEditor.putLong("timeleft", START_TIME_IN_MILLIS);
                timerEditor.putBoolean("timer", isTimerRunning);
                timerEditor.putInt("likeCounts", 0);
                timerEditor.commit();
                likeCounts = 0;
                resetTimer();
            }
        }.start();

        isTimerRunning = true;


    }
    private void resetTimer() {
        mTimeLeftInMillis = START_TIME_IN_MILLIS;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // R.menu.mymenu is a reference to an xml file named mymenu.xml which should be inside your res/menu directory.
        // If you don't have res/menu, just create a directory named "menu" inside res
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // handle button activities
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.mybutton) {
            // do something here
            Toast.makeText(MainActivity.this,"stats",Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}